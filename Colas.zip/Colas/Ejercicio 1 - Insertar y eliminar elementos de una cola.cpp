#include<iostream>
#include<conio.h>
#include<stdlib.h>
using namespace std;

struct Nodo{
	char nombre[10];
	char placa[10];
	char codigo[10];
	Nodo *siguiente;	
};

//Prototipos de Funciones
void menu();
void insertarCola(Nodo *&,Nodo *&,char);
bool cola_vacia(Nodo *);
void suprimirCola(Nodo *&,Nodo *&,char &);

int main(){
	
	menu();
	
	getch();
	return 0;
}

void menu(){
	int opc;
	char codigo;
	char placa;
	char nombre;
	
	Nodo *frente = NULL;
	Nodo *fin = NULL;
	
	do{
		cout<<"\t.:MENU:.\n";
		cout<<"1. Insertar un Conductor"<<endl;
		cout<<"2. Mostrar todos los conductores"<<endl;
		cout<<"3. Salir"<<endl;
		cout<<"Opcion: ";
		cin>>opc; 
		
		switch(opc){
			case 1: cout<<"\nIngrese codigo: ";
					cin>>codigo;
					insertarCola(frente,fin,codigo);
					
					cout<<"\nIngrese placa: ";
					cin>>placa;
					insertarCola(frente,fin,placa);
					
					cout<<"\nIngrese nombre: ";
					cin>>nombre;
					insertarCola(frente,fin,nombre);
					
					break;
			case 2: cout<<"\nMostrando los elementos de la cola: ";
					while(frente != NULL){
						suprimirCola(frente,fin,codigo);
						if(frente != NULL){
							cout<<codigo<<" , ";
						}
						else{
							cout<<codigo<<".";
						
						}
					}
					cout<<"\n";
					system("pause");
					break;
			case 3: break;
		}
		system("cls");
	}while(opc != 3);
}

//Funci�n para insertar elementos en la cola
void insertarCola(Nodo *&frente,Nodo *&fin){
	
	Nodo *nuevo_nodo = new Nodo();
	nuevo_nodo = frente;
	
	
	if(cola_vacia(frente)){
		frente = nuevo_nodo;
	}
	else{
		fin->siguiente = nuevo_nodo;
	}
	
	fin = nuevo_nodo;
}

//Funci�n para determinar si la cola est� vacia
bool cola_vacia(Nodo *frente){
	return (frente == NULL)? true : false; 
}

//Funci�n para eliminar elementos de la cola
void suprimirCola(Nodo *&frente,Nodo *&fin,char &n){
	n = frente->codigo;
	Nodo *aux = frente;
	
	if(frente == fin){
		frente = NULL;
		fin = NULL;
	}
	else{
		frente = frente->siguiente;
	}
	delete aux;
}
