#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <fstream>
using namespace std;

void escribir();
void lectura();
void agregar();
void menu();

void menu(){
	int opc;
	
	do{
		cout<<"menu\n";
		cout<<"\n1. crear archivo";
		cout<<"\n2. cargar datos";
		cout<<"\n3. agregar datos";
		cout<<"\n4. salir";
		cin>>opc;
		
		switch(opc){
			case 1:
				escribir();
				cout<<"archivo creado \n";
				system("pause");
				break;
				
			case 2:	
			    
				system("pause");
				break;
			caso 3:
				
				system("pause");
				break;
		}
	}
}

void escribir(){
	ofstream archivo;
	archivo.open("prueba.txt",ios::out);
	
	if(archivo.fail()){
		cout<<"\n Error no se puede crear";
		exit(1);
	}
}
