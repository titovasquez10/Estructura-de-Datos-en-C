#include<stdio.h>
#include<conio.h>
#include<String.h>

struct videJuego{
	
	char nombre[15];
	char direccion[30];
	int telefono;
	int codigo;
	
}client1, client2;

main(){
	
	strcpy(client1.nombre,"TITO");
	strcpy(client1.direccion,"CALLE 60 #27-41");
	client1.telefono = 3146361;
	client1.codigo = 1143854;

	strcpy(client2.nombre,"ANGIE");
	strcpy(client2.direccion,"CARRERA 11B # 64-10");
	client2.telefono = 3148234;
	client2.codigo = 154713;
	
	printf("CLIENTE 1: ");
	printf("Nombre: %s\n Direccion: %s\n Telefono: %d\n Codigo: %d\n",client1.nombre,client1.direccion,client1.telefono,client1.codigo);
	printf("\nClIENTE 2: \n");
	printf("Nombre: %s\n Direccion: %s\n Telefono: %d\n Codigo: %d\n",client2.nombre,client2.direccion,client2.telefono,client2.codigo);
	
	getch();
}
