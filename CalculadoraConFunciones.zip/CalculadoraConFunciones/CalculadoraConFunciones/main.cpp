//
//  main.cpp
//  CalculadoraConFunciones
//
//  Created by Usuario on 21/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//


#include <stdio.h>
#include <istream>

int num1, num2;

int suma (int a, int b)
{
    int sum;
    sum = a + b;
    
    return sum;
}

int resta (int a, int b)
{
    int rest;
    rest = a - b;
    
    return rest;
}

int multiplicacion (int a, int b)
{
    int multi;
    multi = a * b;
    
    return multi;
}

int division (int a, int b)
{
    int divi;
    divi = a / b;
    
    return divi;
}


void llamar(int& num1, int& num2)
{
    
    printf("\nDigite el primer numero: ");
    scanf("%d",&num1);

    printf("\nDigite el segungo numero: ");
    scanf("%d",&num2);
}


int main() {
    
    
    int opcion;
    
    
    
    printf("***********");
    printf("CALCULADORA");
    printf("***********");
    printf("\n\n1. - Sumar");
    printf("\n2. - Restar");
    printf("\n3. - Multiplicaciíon");
    printf("\n4. - Dividir");
    printf("\n5. - Salir");
    
    
    printf("\n\n Elega una opcion: ");
    scanf("%d",&opcion);
    
    
    switch (opcion) {
        case 1: /*SUMA*/
            llamar(num1,num2);
            //int resp= suma(int a, int b);
            
            //sum = a + b;
            printf("\nLa suma de %d +  %d = %d \n", num1, num2);
            
            break;
            
        case 2: /*RESTA*/
            printf("\nDigite el primero numero: ");
            scanf("%d",&num1);
            
            printf("\nDigite el segundo numero: ");
            scanf("%d",&num2);
            
     //       total = num1 - num2;
       //     printf("\nLa resta de %d -  %d = %d \n", num1, num2,total);
            break;
            
        case 3: /*MULTIPLICACIÓN*/
            printf("\nDigite el primer numero: ");
            scanf("%d",&num1);
            
            printf("\nDigite el segundo numero: ");
            scanf("%d",&num2);
            
       //     total = num1 * num2;
         //   printf("\nLa multiplicacion de %d *  %d = %d \n", num1, num2,total);
            break;
            
        case 4: /*DIVISION*/
            printf("\nDigite el primer numero: ");
            scanf("%d",&num1);
            
            printf("\nDigite el segundo numero: ");
            scanf("%d",&num2);
            
        //    total = num1 / num2;
       //     printf("\nLa division de %d /  %d = %d \n", num1, num2,total);
            break;
       
    }
    
    return 0;
}
