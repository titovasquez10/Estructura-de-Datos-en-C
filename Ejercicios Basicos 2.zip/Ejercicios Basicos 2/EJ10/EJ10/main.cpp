//
//  main.cpp
//  EJ10
//
//  Created by Usuario on 28/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>

int calculo(int num1);
int num;
void leerNumero();
int acomulador = 1;

int main(int argc, const char * argv[]) {
   
    leerNumero();
    calculo(num);
    
    
    return 0;
}

void leerNumero()
{
    printf("Digite un numero: ");
    scanf("%d",&num);
}

int calculo(int num1)
{
    for(int n=1; n<=num; n++) {
        acomulador *= n;
        printf ("\nEl factorial de %d = %d \n",n,acomulador);
        
    }
    return 0;
}
