#include <stdio.h>
#include <conio.h>
#include <String.h>
#include <stdlib.h>


const int N = 4; 
const int M = 4;

int calculo[N] [M]; 
int fila, col; 
int suma1 = 0;


main()
{

// captura de datos

printf("digite una matriz de %d x %d \n\n",N,M);

	for (fila = 0; fila < N; fila++){
		
		for (col = 0; col < M; col++){

	scanf("%d",&calculo[fila][col]);
	
	
	}

}

// visualiza los elementos de la matriz y su posici�n

	for (fila = 0; fila < N; fila++){

		for (col = 0; col < M; col++){ 
	
		suma1 = calculo[0][0] + calculo[1][1] + calculo[2][2] + calculo[3][3];
		
		}

}

printf("\n La suma de la matriz diagonal es: %d",suma1);

}
