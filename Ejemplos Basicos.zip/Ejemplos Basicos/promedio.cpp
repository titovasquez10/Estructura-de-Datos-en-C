#include<stdio.h>

main()
{

	float  nota1;
	float  nota2; 
	float  nota3;
	float  prom;
	
	printf("Ingrese nota 1:  ");
	scanf("%f",&nota1);
	
	printf("Ingrese nota 2:  ");
	scanf("%f",&nota2);
	
	printf("Ingrese nota 3:  ");
	scanf("%f",&nota3);
	
	prom = (nota1+nota2+nota3)/3; 
	
	if(prom > 3)
	{
		printf("Arpovado");
	}
	
	else
	{
		printf("Reprobado");
	}
}
