//
//  main.cpp
//  EJ8
//
//  Created by Usuario on 28/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>

int operacion(int num1);
int nota;
void leerDatos();
int contador=0, contador1=0, contador2=0, acumayor=0, acumenor=0;
float promenor, promayor;

int main(int argc, const char * argv[]) {
    
    leerDatos();
    operacion(nota);
    
    return 0;
}


void leerDatos()
{
    while(contador<=5){

    printf("\n Ingrese 6 notas: ");
    scanf("%d",&nota);
    }
        
}

int operacion(int num1)
{
    if (nota>=3){
        acumayor=acumayor+nota;
        contador1++;}
    else{
        acumenor=acumenor+nota;
        contador2++;
    }
    contador++;

    promayor=acumayor/contador1;
    promenor=acumenor/contador2;
    
    printf("\n El Promedio De Las Notas Perdidas Es: %f", promenor);
    printf("\n\n El Promedio De Las Notas Ganadas Es: %f", promayor);
    printf("\n\n La Cantidad De Notas Perdidas Es: %d", contador2);
    printf("\n\n La Cantidad De Notas Ganadas Es %d", contador1);
    
    return 0;
}
