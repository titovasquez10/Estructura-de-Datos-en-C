#include<iostream>
#include<conio.h>
#include<stdlib.h>
using namespace std;

struct Nodo{
	int dato;
	Nodo *siguiente;
};

void menu();
void insertarLista(Nodo *&,int);
void mostrarLista(Nodo *);
void buscarLista(Nodo *,int);
void eliminarNodo(Nodo *&,int);
Nodo *lista = NULL;
int main(){

	menu();
	getch();
	return 0;
}

/* insertar elementos de una lista */
void insertarLista(Nodo *&lista,int n){
	Nodo *nuevo_nodo = new Nodo();
	nuevo_nodo ->dato = n;
	
	Nodo *aux1 = lista;
	Nodo *aux2;
	
	while((aux1 != NULL)&&(aux1->dato <n)){
		aux2 = aux1;
		aux1 = aux1->siguiente;
	}
	if(lista == aux1)
	{		
		lista = nuevo_nodo;
	}
	else
	{
		aux2->siguiente = nuevo_nodo;		
	}	
	
	nuevo_nodo->siguiente =aux1;
	cout<<"Elemento: "<<n<<"\ninsertado a lista correctamente\n";
}

/* mostrar elementos de una lista */
void mostrarLista(Nodo *lista){
	Nodo *actual = new Nodo();		//creamos un nuevo nodo y reservamos memoria
	actual = lista;					// el puntero debe se�alar a la lista
	
	while(actual != NULL){			// recorra la lista mientras no llegue a null
		cout<<actual->dato<<"->";	//imprime los datos y ->
		actual = actual->siguiente;		// para que avance
	}
}

void buscarLista(Nodo *lista,int n){
	bool band= false;				// creamos una variable bandera que me sirva para saber si esta o no el elemento
	Nodo *actual=new Nodo();    // creamos un nuevo nodo
	actual=lista;				// que apunte a la cabeza de la lista
	
	while((actual !=NULL)&&(actual->dato <=n)){ // busque y compare
		if(actual->dato ==n){
			band = true;			// si es true significa que si encontro el elemento buscado
		}
		actual = actual->siguiente;
	}
	if(band ==true){
		cout<<"Elemento\n" <<n<<"se encontro en la lista \n";		
	}	
	else{
		cout<<"Elemento\n" <<n<<" NO se encontro en la lista \n";	
	}
		
}

void eliminarNodo(Nodo *&lista, int n){			// n es el elemento a borrar
	if(lista !=NULL){					// se verifica si la lista esta vacia, de lo contrario no hace nada
		Nodo *aux_borrar;				// creamos los nodos auxiliares
		Nodo *anterior=NULL;
		aux_borrar=lista;				// apunta al inicio de la lista
		
		while((aux_borrar != NULL)&&(aux_borrar->dato !=n)){		//recorre la lista si cumple las condiciones
			anterior =aux_borrar;							
			aux_borrar= aux_borrar->siguiente;			
		}
		
		if(aux_borrar==NULL){						//el elemento no se ha encontrado
			cout<<"elemento no existe";			
			}
		else if(anterior==NULL){				//significa que el primer elemento es el que vamos a borrar
			lista=lista->siguiente;
			delete aux_borrar;
		}
		else{									// el elemento esta en la lista pero no es el primer nodo
			anterior->siguiente =aux_borrar->siguiente;
			delete aux_borrar;
		}
	}	
}




/* menu */
void menu(){
	int opc;
	int dato;
	
	do{
		cout<<"MENU:\n";
		cout<<"1. Insertar elementos a la lista\n";
		cout<<"2. Mostrar elementos de la lista\n";
		cout<<"3. Buscar elemento de la lista\n";
		cout<<"4. Eliminar elemento de la lista\n";
		cout<<"5. Salir\n";
		cout<<"opcion..\n";
		cin>>opc;
		
		switch(opc){
			case 1:
				cout<<"digite un numero:\n";
				cin>>dato;
				insertarLista(lista,dato);
				cout<<"\n";
				system("pause");	
				break;
			case 2: mostrarLista(lista);		
				cout<<"\n";
				system("pause");				
				break;
			case 3: 
				cout<<"digite un numero a buscar:\n";
				cin>>dato;
				buscarLista(lista,dato);		//le mandamos la lista y el dato a buscar
				cout<<"\n";
				system("pause");				
				break;					
			case 4: 
				cout<<"digite un numero a eliminar:\n";
				cin>>dato;
				eliminarNodo(lista,dato);		//le mandamos la lista y el dato a buscar
				cout<<"\n";
				system("pause");				
				break;
		}		
		system("cls");
	}while(opc !=5);
	
}
