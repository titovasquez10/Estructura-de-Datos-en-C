#include <String.h>
#include <conio.h>
#include <stdio.h>

main(){
	
	int arreglo[9];
	int i, j;

	
	for(i=0; i<10; i++){
		printf("Digite numeros [%d]: ",i);
		scanf("%d",&arreglo[i]);	
	}
	int t;
	
	for(i=1; i<10; i++){
			
			for(j<0; j<10; j++){
			if(arreglo[j] > arreglo[j+1]){
				t = arreglo[j];
				arreglo[j] = arreglo[j+1];
				arreglo[j+1] = t; 
			}
		}
	}
	
	for(int i=0; i<10; i++){
	printf("\n Numero %d",arreglo[i]);
	}
	
}
