//
//  main.cpp
//  EJ9
//
//  Created by Usuario on 28/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>

int operacion(int num1);
void leerNumeros();
int num,  cuadrado, cubo ;
float el_doble;
double mitad;

int main(int argc, const char * argv[]) {
    
    leerNumeros();
    operacion(num);
    
    return 0;
}

void leerNumeros()
{
    printf("\nDigite un numero: ");
    scanf("%d",&num);
}

int operacion(int num1)
{
    mitad = num / 2;
    el_doble = num + num;
    cuadrado = num*num;
    cubo = num*num*num;
    
    printf("\nMitad: %f", mitad);
    printf("\nDoble: %f", el_doble);
    printf("\nCuadrado: %d",cuadrado);
    printf("\nCubo: %d \n",cubo);
    
    return 0;
}
