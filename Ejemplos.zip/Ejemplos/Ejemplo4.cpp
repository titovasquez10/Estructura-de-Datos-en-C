#include <String.h>
#include <conio.h>
#include <stdio.h>

struct videJuego{
	
	char nombre[15];
	char direccion[30];
	int telefono;
	int codigo;
	
}cliente1;

main(){
	
	printf("CLIENTE 1: \n");
	
	printf("\nDigite nombre: ");
	gets(cliente1.nombre);
	printf("Digite direccion: ");
	gets(cliente1.direccion);
	printf("Ingrese telefono: ");
	scanf("%d",&cliente1.telefono);
	printf("Ingrese codigo: ");
	scanf("%d",&cliente1.codigo);
	
	printf("\nNOMBRE: %s\n DIRECCION: %s\n TELEFONO: %d\n CODIGO: %d\n",cliente1.nombre,cliente1.direccion,cliente1.telefono,cliente1.codigo);
	
	getch();
	
}
