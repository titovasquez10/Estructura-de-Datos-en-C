//
//  main.cpp
//  EJ7
//
//  Created by Usuario on 28/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>

int calculo(int num);
void leerDatos();
int num1, resultado, r;
int cont = 1;

int main(int argc, const char * argv[]) {
    
    leerDatos();
    calculo(r);
    return 0;
}

void leerDatos()
{
    printf("Digite un numero del 1 - 9: ");
    scanf("%d",&num1);
}


int calculo(int num)
{
    if(num1 <= 9){
        while(cont<11)
        {
            resultado = num1*cont;
            cont++;
            printf("\n %d \n",resultado);
        }
    }
    else{
        printf("\nEl numero a ingresar debe estar en un rango de 1-9");
    }
    
    r = resultado;
    return r;

    
}
