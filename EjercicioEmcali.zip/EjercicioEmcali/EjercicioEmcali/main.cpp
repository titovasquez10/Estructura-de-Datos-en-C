//
//  main.cpp
//  EjercicioEmcali
//
//  Created by Usuario on 21/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>

int main(int argc, const char * argv[]) {
   
    int consumo;
    int valor;
    int estrato;
    
    
    printf("\n******BIENVENIDO*****");
    
    printf("\n 1. - ESTRATO");
    printf("\n 2. - ESTRATO");
    printf("\n 3. - ESTRATO");
    printf("\n 4. - ESTRATO");
    printf("\nIGRESE SU ESTRATO: ");
    scanf("%d",&estrato);
    
    switch (estrato) {
        case 1: printf("Digite el valor de la factura: ");
            scanf("%d,",&valor);
            consumo = valor + 500;
            printf("El valor a pagar total a pagar es de %d",consumo);
            break;
            
        case 2: printf("Digite el valor de la factura: ");
            scanf("%d,",&valor);
            consumo = valor + 700;
            printf("El valor a pagar total a pagar es de %d",consumo);
            
        case 3: printf("Digite el valor de la factura: ");
            scanf("%d,",&valor);
            consumo = valor + 4800;
            printf("El valor a pagar total a pagar es de %d",consumo);
            
        case 4: printf("Digite el valor de la factura: ");
            scanf("%d,",&valor);
            consumo = valor + 6700;
            printf("El valor a pagar total a pagar es de %d",consumo);
            
        default: printf("Categoria no valida");
            break;
    }
    
    return 0;
}
