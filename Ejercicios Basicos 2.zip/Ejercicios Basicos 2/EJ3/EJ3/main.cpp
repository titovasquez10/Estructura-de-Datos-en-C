//
//  main.cpp
//  EJ3
//
//  Created by Usuario on 27/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>

float calculo(float total);
float r;
void dias();
float horas_extras;
float resta;
int lunes, martes, miercoles, jueves, viernes, sabado, domingo;
float suma_horas_dias;

int main(int argc, const char * argv[]) {
    
    dias();
    calculo(r);
    
    return 0;
}


void dias()
{
    printf("\nIngresar las horas que trabajo cada dias: \n");
    
    printf("\nLunes: ");
    scanf("%d",&lunes);
    
    printf("\nMartes: ");
    scanf("%d",&martes);
    
    printf("\nMiercoles: ");
    scanf("%d",&miercoles);
    
    printf("\nJueves: ");
    scanf("%d",&jueves);
    
    printf("\nViernes: ");
    scanf("%d",&viernes);
    
    printf("\nSabado: ");
    scanf("%d",&sabado);
    
    printf("\nDomingo: ");
    scanf("%d",&domingo);
    
    suma_horas_dias = lunes + martes + miercoles + jueves + viernes + sabado + domingo;
    
}

float calculo(float total)
{
    if (suma_horas_dias<=40) {
        total = suma_horas_dias*16;
        printf("\nEl sueldo semanal es de: %f",total);
    }
    else{
        if (suma_horas_dias >= 40){
            resta = suma_horas_dias - 40;
            horas_extras = resta * 20;
            
            printf("\nEl sueldo semanal de las horas extras es de: %f",horas_extras);
            
            total = (suma_horas_dias - resta)*16;
            printf("\nEl sueldo semanal es de primeras 40 horas es de: %f",total);
        }
    }
    
    r = total;
    
    return r;
}


