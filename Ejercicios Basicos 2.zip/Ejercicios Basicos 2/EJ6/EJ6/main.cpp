//
//  main.cpp
//  EJ6
//
//  Created by Usuario on 27/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>

int calculo(int num);
void pedirNum();
int sumar, r;
int  num1, num2, num3, num4, num5;

int main(int argc, const char * argv[]) {
   
    pedirNum();
    calculo(r);
    return 0;
}

void pedirNum()
{

    printf("Digite 5 numeros: ");
    
    printf("\nDigite el primer numero:");
    scanf("%d",&num1);
    
    printf("\nDigite el segundo numero: ");
    scanf("%d",&num2);
    
    printf("\nDigite el tercer numero: ");
    scanf("%d",&num3);
    
    printf("\nDigite el cuarto numero: ");
    scanf("%d",&num4);
    
    printf("\nDigite el quinto numero: ");
    scanf("%d",&num5);
    
}


int calculo(int num)
{
    
    num = num1 + num2 + num3 + num4 + num5;
    printf("El total de la suma es de: %d \n",num);
    r = num;
   
    return r;
    
}


