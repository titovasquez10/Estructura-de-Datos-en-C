#include<stdio.h>
#include<conio.h>

main()
{
	int num;
	int cont=1;
	int resultado;
	
	printf("Dijite un numero:  ");
	scanf("%d",&num);
	
	while(cont<10)
	{
	 	resultado = num*cont;
		cont++;
		printf("\nResultado es: %d",resultado);
	}
	
	return 0;
}
