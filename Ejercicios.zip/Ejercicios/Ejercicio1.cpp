#include<conio.h>

#include<stdio.h>

const int N = 3; 
const int M = 5;

float calculo[N] [M]; 
int fila, col; 
float suma1 = 0;
float suma2 = 0;
float suma3 = 0;
float cont1 = 0;

main()
{

// captura de datos

printf("digite una matriz de %d x %d \n\n",N,M);

	for (fila = 0; fila < N; fila++){
		
		for (col = 0; col < M; col++){

	scanf("%f",&calculo[fila][col]);
	
	
	}
	

}
			
// visualiza los elementos de la matriz y su posici�n

	for (fila = 0; fila < N; fila++){

		for (col = 0; col < M; col++){ 
	
		suma1 = calculo[0][0] + calculo[0][1] + calculo[0][2] + calculo[0][3] + calculo[0][4];
		suma2 = calculo[1][0] + calculo[1][1] + calculo[1][2] + calculo[1][3] + calculo[1][4];
		suma3 = calculo[2][0] + calculo[2][1] + calculo[2][2] + calculo[2][3] + calculo[2][4];
		}

}

printf("\n La primera fila es: %f",suma1);
printf("\n La segunda fila es: %f",suma2);
printf("\n La tercera fila es: %f",suma3);


getch();

}

/* programa que crea una matriz de 2X2 y la muestra en pantalla */

