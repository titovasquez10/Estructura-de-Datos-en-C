#include <stdio.h>
#include <conio.h>
#include <String.h>

struct datos {
	int codigo;
	char marca[10];
	int modelo;
	float cilindraje;
	char placa[6];
	
}cliente1, cliente2;

main(){
	
	cliente1.codigo = 123;
	strcpy(cliente1.marca,"DODGE");
	cliente1.modelo = 1987;
	cliente1.cilindraje = 2.600;
	strcpy(cliente1.placa,"BYB080");
	
	cliente2.codigo = 456;
	strcpy(cliente2.marca,"BMW");
	cliente2.modelo = 2019;
	cliente2.cilindraje = 3.0;
	strcpy(cliente2.placa,"BDS090");
	
	printf("CLIENTE 1: \n");
	printf("Codigo: %d\n Marca: %s\n Modelo: %d\n Cilindraje: %f\n Placa: %s\n ",cliente1.codigo, cliente1.marca, cliente1.modelo, cliente1.cilindraje, cliente1.placa);
	
	printf("\nCLIENTE 2: \n");
	printf("Codigo: %d\n Marca: %s\n Modelo: %d\n Cilindraje: %f\n Placa: %s\n ", cliente2.codigo, cliente2.marca, cliente2.modelo, cliente2.cilindraje, cliente2.placa);
	
	getch();
}

