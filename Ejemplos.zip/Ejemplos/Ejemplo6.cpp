#include <String.h>
#include <conio.h>
#include <stdio.h>

struct datos{
	
	int matricula;
	char nombre[20];
	char carrera[20];
	float promedio;
	char direccion[20];
	
}estudiante1, estudiante2;

main(){
	
	printf("\nESTUDIANTE 1: ");
	printf("\nDigite matricula: ");
	scanf("%d",&estudiante1.matricula);
	fflush(stdin);
	printf("\nDigite nombre: ");
	gets(estudiante1.nombre);
	printf("\nDijite carrera: ");
	gets(estudiante1.carrera);
	printf("\nDijite promedio: ");
	scanf("%f",&estudiante1.promedio);
	printf("\nDijite direccion: ");
	gets(estudiante1.direccion);
	fflush(stdin);
	
	//DATOS PARA MOSTRAR EN PANTALLA
	printf("\nDATOS ESTUDIANTE 1: ");
	printf("%d",estudiante1.matricula);
	puts(estudiante1.nombre);
	puts(estudiante1.carrera);
	printf("%f",&estudiante1.promedio);
	puts(estudiante1.direccion);
	
	
	
}
