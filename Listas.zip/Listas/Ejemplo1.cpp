#include<stdio.h>  
#include<conio.h>  
#include<stdlib.h>

struct nodo{  
int info;
struct nodo *sgt;
};

main(){
	struct nodo *cabe; 
	struct nodo *nuevo;  
	struct nodo *aux;  
	cabe=NULL;	
	int dato;
	int cant, i=1, cont;

	printf("digite cuantos nodos para la lista");
	scanf("%d",&cant); 
	
	while(i<=cant) {
		
		nuevo=(struct nodo *)malloc(sizeof(struct nodo)); 
 		nuevo->sgt=cabe;
		printf("digite valor del nodo");  
		scanf("%d",&dato);
		nuevo->info=dato;

		cabe=nuevo;  i++;
	}
	
	while(nuevo!=NULL){  
		
		printf("\ndato %d",nuevo->info);  nuevo=nuevo->sgt;
	}
	getch();
}


