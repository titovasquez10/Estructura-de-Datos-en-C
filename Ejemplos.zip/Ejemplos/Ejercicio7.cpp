#include <String.h>
#include <conio.h>
#include <stdio.h>

struct alumno{
	
	int matricula;
	char nombre[20];
	
}estudiante[3];

main(){
	
	int i;
	for(i=1; i<=3; i++){
		
		printf("Ingrese matricula del estudiante [%d]\n",i);
		scanf("%d",&estudiante[i].matricula);
		fflush(stdin);
		printf("Dijite Nombre[%d]\n",i);
		gets(estudiante[i].nombre);
	}
	
	for(i=1; i<=3; i++){
		printf("\nDATOS ALUMNO [%d]\n",i);
		printf("%d\n",&estudiante[i].matricula);
		printf("%s\n",&estudiante[i].nombre);
	}
	
	getch();
}
