#include<iostream>
#include<conio.h>
#include<stdlib.h>		//para reservar espacion en memoria new()
#define maxchar 50
using namespace std;

struct Nodo{
	int cod;
	char nombre[maxchar];
	char detalle[maxchar];
	int valor;
	struct Nodo *siguiente;
};

typedef struct nodo *pila;
void agregarPila(Nodo *pila);    //prototipo

int main(){
	Nodo *pila = NULL;		//Creamos una pila que en este momento apunta a NULL
	agregarPila(pila);			//llamamos a la funcion y enviamos la pila y el elemento digitado
	getch;
	return 0;
}

///// AGREGAR ELEMENTOS DE UNA PILA   ////////

void agregarPila(Nodo *pila){				//creamos la funcion y pasamos por referencia a pila porque varia en el transcurso de la ejecucion
	
	Nodo *nuevo_nodo =new Nodo();		//Reservamos memoria para el nodo
	fflush(stdin);
	cout<<"\n\n\t\tINVENTARIO DE PRODUCTOS:";
	cout<<"\n\n\tCODIGO:"; 
	cin>>nuevo_nodo->cod;					
    fflush(stdin);
	cout<<"\n\tNOMBRES:"; 
	cin.getline(nuevo_nodo->nombre,maxchar);  
	fflush(stdin);
	cout<<"\n\tDETALLE:"; 
	cin.getline(nuevo_nodo->detalle,maxchar);  
	cout<<"\n\tVALOR:";
	cin>>nuevo_nodo->valor;
	
	nuevo_nodo->siguiente=pila;		//apuntamos el puntero a pila que vale NULL
	pila = nuevo_nodo;				//pila queda en la punta de la pila
	
	cout<<"\n\n\t Dato ingresado!!!\t\t\t\t";
	cout<<nuevo_nodo->cod<<"--> ";
	cout<<nuevo_nodo->nombre<<"-->";
	cout<<nuevo_nodo->detalle<<"-->";
	cout<<nuevo_nodo->valor<<"\n";
}

