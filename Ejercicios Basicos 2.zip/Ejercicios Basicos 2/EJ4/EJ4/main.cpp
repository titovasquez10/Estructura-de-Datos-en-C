//
//  main.cpp
//  EJ4
//
//  Created by Usuario on 27/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>

int operacion(int num_pares);
int r;

int main(int argc, const char * argv[]) {
    
    operacion(r);
    
    return 0;
}

int operacion(int num_pares)
{
    
    for(num_pares = 1; num_pares <= 200; num_pares++){
        
        if (num_pares % 2 == 0) {
            printf("\n %d ",num_pares);
        }
    }
    r = num_pares;
    return r;
}
