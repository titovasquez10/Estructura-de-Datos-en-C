#include<conio.h>
#include<stdio.h>
const int N = 3;
const int M = 2;
int calculo[N] [M];
int fila, col;
main()
{
// captura de datos
printf("digite una matriz de %d,%d \n\n",N,M);
for (fila = 0; fila < N; fila++){

for (col = 0; col < M; col++){

scanf("%d",&calculo[fila][col]);

}

}
// visualiza los elementos de la matriz y su posici�n
for (fila = 0; fila < M; fila++){

for (col = 0; col < N; col++){

printf(" (F%d,C%d)=",fila,col);
printf(" %d",calculo[col][fila]);

}
printf("\n");





}
getch();
}
