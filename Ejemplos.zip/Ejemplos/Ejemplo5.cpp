#include <String.h>
#include <conio.h>
#include <stdio.h>

struct libro{
	
	char titulo [20], autor[15], editorial[20];
	int anho,edicion;
};

main(){
	
	libro a = {"EL QUIJOTE","CERVANTES","LIMUSA",1987,2},b;

	b = a;

	printf("Titulo: %s\n Autor: %s\n Editorial: %s\n Anio: %d\n Edicion: %d\n",a.titulo,a.autor,a.editorial,a.anho,a.edicion);

getch();

}

