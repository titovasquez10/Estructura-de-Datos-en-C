#include <iostream>
#include <conio.h>
#include <stdlib.h>

using namespace std;

struct Nodo{
	
	int codigo;
	char nombre;
	char detalle;
	float valor;
	Nodo *siguiente;
		
};
void menu();
void agregarPila(Nodo &,int);
void sacarPila(Nodo *&,int &);
Nodo *pila = NULL;

int main(){
	
	menu();
	getch();
	return 0;
	
}



void agregarPila(Nodo *Pila,int n){

	Nodo *nuevo_nodo = new Nodo();
	nuevo_nodo->dato=n;
	nuevo_nodo->siguiente=pila;
	pila = nuevo_nodo;
	
	cout<<"\n elemento ->" <<n<<"\nagregar a la PILA \n"<<endl;
}

void mostrarLista(Nodo *lista){
	Nodo *actual = new Nodo();		
	actual = lista;					
	
	while(actual != NULL){			
		cout<<actual->dato<<"->";	
		actual = actual->siguiente;		
	}
}


/* menu */
void menu(){
	int opc;
	int dato;
	
	do{
		cout<<"MENU:\n";
		cout<<"1. Insertar elementos a la lista\n";
		cout<<"2. Mostrar elementos de la lista\n";
		cout<<"3. Salir\n";
		cin>>opc;
		
		switch(opc){
			case 1:
				cout<<"digite un numero:\n";
				cin>>dato;
				insertarLista(lista,dato);
				cout<<"\n";
				system("pause");	
				break;
			case 2: mostrarLista(lista);		
				cout<<"\n";
				system("pause");				
				break;
		}		
		system("cls");
	}while(opc !=3);
	
}

