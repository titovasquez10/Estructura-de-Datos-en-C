#include <String.h>
#include <stdio.h>
#include <conio.h>

//MATRIZ 1
const int N = 2;
const int M = 2;

//MATRIZ 2
const int X = 2;
const int Y = 2;

int datos1[N] [M]; //MATRIZ 1

int datos2[X] [Y]; //MATRIZ 2

int matrizSuma[N] [M]; //SUMA DE MATRICES
int matrizResta[N] [M]; //RESTA DE MATRICES
int matrizMultiplicacion[N][M]; //MULTIPLICACION DE MATRICES
int matrizEscalar[N][M]; //ESCALAR DE UNA MATRIZ

int filas, columnas, k;
int eleccion, escalar;

int suma = 0;

main(){

//CAPTURA LOS DATOS DE LA MATRIZ 1
	
	printf("\---BIENVENIDO---");
	printf("\n---MATRIZ 1---");
	printf("\n---%d x %d---\n\n",N,M);
	
	
	for(filas=0; filas<N; filas++){
	
		for(columnas=0; columnas<M; columnas++){
		
		printf("(F%d,C%d)= ",filas,columnas);
		scanf("%d",&datos1[filas][columnas]);
		
		}
	}		


//CAPTURA LOS DATOS DE LA MATRIZ 2

	printf("\---BIENVENIDO---");
	printf("\n---MATRIZ 2---");
	printf("\n---%d x %d---\n\n",X,Y);
	
	
	for(filas=0; filas<X; filas++){
	
		for(columnas=0; columnas<Y; columnas++){
	
		printf("(F%d,C%d)= ",filas,columnas);
		scanf("%d",&datos2[filas][columnas]);
		
		}
	}	

//VISUALIZA LOS DATOS DE LA MATRIZ 1

	printf("\nDatos Matriz 1\n");
	for(filas=0; filas<N; filas++){
	
	for(columnas=0; columnas<M; columnas++){
		
		printf("(F%d,C%d) = ",filas,columnas);
		printf("%d",datos1[filas][columnas]);
		}
	printf("\n");
	
	}		

//VISUALIZA LOS DATOS DE LA MATRIZ 2	

	printf("\nDatos Matriz 2\n");
	for(filas=0; filas<X; filas++){
	
	for(columnas=0; columnas<Y; columnas++){
		
		
		printf("(F%d,C%d) = ",filas,columnas);
		printf("%d",datos2[filas][columnas]);
		}
	printf("\n");

	}		

//SUMA DE LA MATRIZ 1 & 2

	if(datos1[N][M] != datos2[X][Y]){  //CONDICION DE 

		printf("\nSuma de las matrices 1 & 2");
		for(filas=0; filas<N&&X; filas++){
			
			for(columnas=0; columnas<M&&Y; columnas++){
		
				matrizSuma[filas][columnas] = datos1[filas][columnas] + datos2[filas][columnas];
				printf("\n  %d",matrizSuma[filas][columnas]);
		}
		printf("\n");
	}	
	
}

	else{
		printf("\nNo es posible sumar las 2 matrices, porque no poseen el mismo numero de filas o columnas\n");
	}

//RESTA DE LA MATRIZ 1 & 2

	if(datos1[N][M] != datos2[X][Y]){  //CONDICION DE 

		printf("\nResta de las matrices 1 & 2");
		for(filas=0; filas<N&&X; filas++){
			
			for(columnas=0; columnas<M&&Y; columnas++){
		
				matrizResta[filas][columnas] = datos1[filas][columnas] - datos2[filas][columnas];
				printf("\n  %d",matrizResta[filas][columnas]);
		}
		printf("\n");
	}	
	
}

	else{
		printf("\nNo es posible restar las 2 matrices, porque no poseen el mismo numero de filas o columnas\n");
	}
	
	
//PRODUCTO ESCALAR DE LA MATRIZ 1 & 2

	printf("\nProducto Escalar");
	printf("\nDigite un numero: ");
	scanf("%d",&escalar);
	printf("Digite 1 para la primera matriz --&&-- 2 para la segunda matriz: ");
	scanf("%d",&eleccion);

	if(eleccion == 1){
	
		for(filas=0; filas<N; filas++){
			
			for(columnas=0; columnas<M; columnas++){
		
				matrizEscalar[filas][columnas] = escalar * datos1[filas][columnas];
				printf("\n  %d",matrizEscalar[filas][columnas]);
		}
		printf("\n");
	}	
}
	
	if(eleccion == 2){
	 
		for(filas=0; filas<X; filas++){
			
			for(columnas=0; columnas<Y; columnas++){
		
				matrizEscalar[filas][columnas] = escalar * datos2[filas][columnas];
				printf("\n  %d",matrizEscalar[filas][columnas]);
		}
		printf("\n");
	}	
}
	else{
		printf("\nOpcion incorreta");
	}
	
	

//MULTIPLICACION DE LA MATRIZ 1 & 2

	if(datos1[N] != datos2[Y]){  //CONDICION

		printf("\nMultiplicacion de las matrices 1 & 2");
		for(filas=0; filas<N&&X; filas++){
	
			for(columnas=0; columnas<M&&Y; columnas++){
			
			matrizMultiplicacion[N][M] = (datos1[filas][0]*datos2[0][columnas] + datos1[filas][0]*datos2[1][columnas] + datos1[filas][1]*datos2[1][columnas] + datos1[filas][1] * datos2[2][columnas] );
			printf("\n  %d",matrizMultiplicacion[filas][columnas]);
			}
		}
		printf("\n");
	}	
		

	else{
		printf("\nNo es posible Multiplicar las 2 matrices, porque no poseen el mismo numero de filas o columnas\n");
	}


getch();
}



