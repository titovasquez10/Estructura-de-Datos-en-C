#include<stdio.h>
#include<conio.h>
main()
{
	printf("Este es mi mejor promagama!!!\n");
	printf("\n Hola mundo");
	getch();
}
