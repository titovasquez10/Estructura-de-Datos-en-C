//
//  main.cpp
//  EJ1
//
//  Created by Usuario on 24/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>
using namespace std;

void leerDatos();
int numMax(int a, int b=100);
int n1, operacion;


int main(int argc, const char * argv[]) {
    
    leerDatos();
    operacion = numMax(n1);
    
    return 0;
}

void leerDatos()
{
    printf("Digite un numero: ");
    scanf("%d",&n1);
}

int numMax(int a, int b)
{
    int resultado;
    
    if(a > b)
        {
        resultado = a;
       printf("\nEl numero es mayor que 100\n");
        }
    else
    {
        return 0;
    }
return resultado;
}
