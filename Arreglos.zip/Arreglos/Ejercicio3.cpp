#include <String.h>
#include <conio.h>
#include <stdio.h>

main(){

int array[4];
int nuevo_arreglo[4];
int i;

	for(i=1; i<6; i++){
	printf("Digite numeros [%d]: ",i);
	scanf("%d",&array[i]);
}

	for(i=1; i<6; i++){
	nuevo_arreglo[i] = array[i] * 2;
	printf("\nNumero %d ",nuevo_arreglo[i]);
}

}
