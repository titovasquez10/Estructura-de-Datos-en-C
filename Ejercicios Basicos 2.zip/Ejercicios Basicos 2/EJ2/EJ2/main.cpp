//
//  main.cpp
//  EJ2
//
//  Created by Usuario on 27/08/18.
//  Copyright © 2018 Usuario. All rights reserved.
//

#include <iostream>
#include <stdio.h>

int valores(int a, int b=18);
void leerDatos();
int edad;

int main(int argc, const char * argv[]) {
    
    leerDatos();
    valores(edad);

    
    
    return 0;
}

void leerDatos()
{
    printf("Digite edad: ");
    scanf("%d",&edad);
}


int valores(int a, int b)
{
    int resultado = 0;
    
    if(a >= b)
    {
        printf("\nEres mayor que 18\n");
    }
    else
    {
        printf("\nEres menor que 18\n");
    }
    return resultado;
}

